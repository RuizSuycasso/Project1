// File: src/main/java/com/example/myapplication/ApiService.java
// Phiên bản cuối cùng, tối ưu cho việc tự động parse JSON

package com.example.myapplication;

import java.util.List; // <<< THÊM IMPORT NÀY

import okhttp3.MultipartBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

public interface ApiService {

    /**
     * Endpoint để tải lên một file ảnh.
     * Retrofit và Gson sẽ tự động parse phản hồi JSON thành một List<DrugInfo>.
     */
    @Multipart
    @POST("ocr")
    // <<< THAY ĐỔI CỐT LÕI: Thay ResponseBody bằng List<DrugInfo> >>>
    Call<List<DrugInfo>> uploadImage(@Part MultipartBody.Part file);

    /**
     * Endpoint để gửi bệnh án và nhận lời khuyên từ AI.
     * Giữ nguyên vì nó phục vụ một mục đích khác.
     */
    @POST("advise_from_record")
    Call<ResponseBody> getAdviceFromRecord(@Body BenhAnRequest benhAnRequest);

}