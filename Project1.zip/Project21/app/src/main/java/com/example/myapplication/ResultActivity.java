// File: src/main/java/com/example/myapplication/ResultActivity.java
// << PHIÊN BẢN ĐÃ SỬA LỖI CÚ PHÁP VÀ LOGIC >>

package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.text.HtmlCompat; // Sử dụng thư viện tương thích

import java.util.ArrayList;

public class ResultActivity extends AppCompatActivity {

    // --- CÁC CHÌA KHÓA CHO INTENT ---
    public static final String EXTRA_RESULT_TEXT = "com.example.myapplication.RESULT_TEXT"; // Dùng cho AI
    public static final String EXTRA_DRUG_LIST = "DRUG_LIST_EXTRA"; // Key mới cho danh sách thuốc
    public static final String EXTRA_RESULT_TYPE = "com.example.myapplication.RESULT_TYPE";

    // --- CÁC GIÁ TRỊ CHO LOẠI KẾT QUẢ ---
    public static final int TYPE_OCR_RESULT = 1;
    public static final int TYPE_AI_ADVICE = 2;

    private TextView resultDetailTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        resultDetailTextView = findViewById(R.id.resultDetailTextView);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        Intent intent = getIntent();
        if (intent == null) {
            showError("Không nhận được dữ liệu.");
            return;
        }

        int resultType = intent.getIntExtra(EXTRA_RESULT_TYPE, 0);

        if (resultType == TYPE_OCR_RESULT) {
            // Xử lý kết quả từ OCR
            ArrayList<DrugInfo> drugList = intent.getParcelableArrayListExtra(EXTRA_DRUG_LIST);
            if (drugList != null && !drugList.isEmpty()) {
                setTitle("Kết quả Phân tích Đơn thuốc");
                displayDrugList(drugList);
            } else {
                showError("Không tìm thấy thông tin thuốc nào.");
            }
        } else if (resultType == TYPE_AI_ADVICE) {
            // Xử lý tư vấn từ AI
            String adviceText = intent.getStringExtra(EXTRA_RESULT_TEXT);
            if (adviceText != null && !adviceText.isEmpty()) {
                setTitle("Tư vấn từ Trợ lý AI");
                displayAIAdvice(adviceText);
            } else {
                showError("Không nhận được lời tư vấn từ AI.");
            }
        } else {
            showError("Loại kết quả không xác định.");
        }
    }

    /**
     * Hiển thị danh sách thuốc đã được phân tích một cách chính xác.
     * @param drugList Danh sách các đối tượng DrugInfo.
     */
    private void displayDrugList(ArrayList<DrugInfo> drugList) {
        // Sử dụng StringBuilder để tạo chuỗi HTML, tương thích với mọi phiên bản Java
        StringBuilder htmlBuilder = new StringBuilder();

        // Tiêu đề chính
        htmlBuilder.append("<h1><font color='#2E7D32'>💊 THÔNG TIN THUỐC</font></h1>");

        // Lặp qua danh sách và hiển thị
        for (int i = 0; i < drugList.size(); i++) {
            DrugInfo drug = drugList.get(i);
            htmlBuilder.append("<br>");
            // Tên thuốc
            htmlBuilder.append("<b><font color='#1976D2'>🔹 Thuốc ").append(i + 1).append(": ").append(escapeHtml(drug.getDrug())).append("</font></b><br>");
            // Liều lượng
            htmlBuilder.append("📋 <i><font color='#F57C00'>Liều lượng: ").append(escapeHtml(drug.getDosage())).append("</font></i><br>");
        }

        // Lời khuyên cuối
        htmlBuilder.append("<br><br>");
        htmlBuilder.append("<h2><font color='#D32F2F'>⚠️ LƯU Ý QUAN TRỌNG</font></h2>");
        htmlBuilder.append("• Hãy tham khảo ý kiến bác sĩ hoặc dược sĩ trước khi sử dụng.<br>");
        htmlBuilder.append("• Kiểm tra kỹ hạn sử dụng và đọc kỹ hướng dẫn sử dụng.<br>");
        htmlBuilder.append("• Không tự ý thay đổi liều lượng đã được chỉ định.");

        // Dùng HtmlCompat để chuyển chuỗi HTML thành văn bản có định dạng
        resultDetailTextView.setText(HtmlCompat.fromHtml(htmlBuilder.toString(), HtmlCompat.FROM_HTML_MODE_LEGACY));
    }

    /**
     * Hiển thị lời tư vấn từ AI.
     * @param adviceText Chuỗi văn bản tư vấn.
     */
    private void displayAIAdvice(String adviceText) {
        setTitle("Tư vấn từ Trợ lý AI");
        resultDetailTextView.setText(adviceText);
    }

    /**
     * Hiển thị thông báo lỗi.
     * @param message Nội dung lỗi.
     */
    private void showError(String message) {
        setTitle("Lỗi");
        resultDetailTextView.setText(message);
    }

    /**
     * Hàm trợ giúp để tránh lỗi khi hiển thị các ký tự đặc biệt của HTML
     */
    private String escapeHtml(String text) {
        if (text == null) return "";
        return text.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;")
                .replace("'", "&#39;");
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}